# ConformalHydride data bundle — provenance

Downloaded 2026-08-09 from https://github.com/mwitman1/HEAhydrideML (branch main), ml_data/.

| file | rows | description |
|---|---|---|
| HYDPARK_ML_ready.csv | 398 | ML-ready cleaned HydPARK metal-hydride thermodynamics (dH kJ/mol H2, dS J/mol H2/K*, lnPeq 25C, wt%), Magpie features precomputed |
| ElementalH_Ef.csv / ElementalH_Ef_MP.csv | 94 | per-element hydride formation energies (Materials Project) |
| rHEA_allpredictions_final.csv | 672 | refractory-HEA candidate pool with Witman GBT predictions (screening pool) |
| HEA_experiments_full.csv | 5 | measured HEA hydride thermodynamics (experimental anchor, Table T12) |

*Column header says kJ/mol/K but values are J/(mol H2 K) — verified via van 't Hoff reconstruction of LnEquilibrium_Pressure_25C.

## Citations (mandatory in the paper)
1. Witman et al. J. Phys. Chem. Lett. 2020, 11, 40–47. doi:10.1021/acs.jpclett.9b02971 (curation procedure)
2. Witman et al. Chem. Mater. 2021, 33, 4067–4076. doi:10.1021/acs.chemmater.1c00647 (HEA augmentation + rHEA pool)
3. ML-HydPARK dataset, Zenodo. doi:10.5281/zenodo.7324809 (versioned dataset of record)
4. Original HydPARK: US DOE Hydrogen Storage Materials Database (public).

## Before journal submission (Stage 3)
- Re-pull the LATEST versioned release from Zenodo, record exact version + license text, rerun pipeline, diff results.
